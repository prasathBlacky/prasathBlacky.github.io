//
//  NetworkManagerProtocol.swift
//  SoftwareGroupWeatherApp
//
//  Created by Prasath Thirumoorthy on 12/04/22.
//

import UIKit

protocol NetworkManagerProtocol {
    func fetchCurrentWeatherLocation(city: String, completion: @escaping (WeatherForeCast)-> ())
    func fetchCurrentWeather(city: String, completion: @escaping (WeatherModel)-> ())
    func fetchCurrentLocationWeather(lat: String, long: String, completion: @escaping(WeatherModel)-> ())
    func fetchNextSevenWeatherForecast(city: String, completion: @escaping
    ([ForecastTemperature])->())
}
