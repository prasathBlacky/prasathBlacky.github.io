//
//  SelfConfiguringCell.swift
//  SoftwareGroupWeatherApp
//
//  Created by Prasath Thirumoorthy on 12/04/22.
//


import UIKit

protocol SelfConfiguringCell {
    static var reuseIdentifier: String { get }
    func configure(with item: ForecastTemperature)
}
