//
//  Date_Extension.swift
//  SoftwareGroupWeatherApp
//
//  Created by Prasath Thirumoorthy on 12/04/22.
//

import UIKit

extension Date {
    func dayOfWeek() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: self).capitalized
    }
}
