//
//  Constants.swift
//  SoftwareGroupWeatherApp
//
//  Created by Prasath Thirumoorthy on 12/04/22.
//

import UIKit

struct Constants {
    static let API_Keys = "522db6a157a748e2996212343221502"
    static let API_Key = "5aa8d384afe4769c566762d5e85249ba"
}
